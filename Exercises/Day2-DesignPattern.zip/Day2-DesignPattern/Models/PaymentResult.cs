namespace Day2DesignPattern.Models
{
    public class PaymentResult
    {
        public bool Titulaire {get; set;}
        public string Amount {get; set;}
    }
}