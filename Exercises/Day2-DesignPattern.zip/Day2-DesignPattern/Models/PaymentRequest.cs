namespace Day2DesignPattern.Models
{
    public class PaymentRequest
    {
        public string Titulaire {get; set;}
        public string Amount {get; set;}
    }
}