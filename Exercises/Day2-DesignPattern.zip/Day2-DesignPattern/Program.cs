﻿using System.Extensions.DependencyInjection;
using Day2DesignPattern.Interfaces;
using Day2DesignPattern.Services;
using Day2DesignPattern.Models;
using Day2DesignPattern.Enums;

var services = new ServiceCollection();

services.AddTransient<MobileMoneyPaymentService>();
services.AddTransient<VirementBancairePaymentService>();
services.AddTransient<CarteBancairePaymentService>();
services.AddTransient<PaymentManager>();
var PaymentManager = services.AddTransient<PaymentFactory>();

var serviceProvider = services.BuildServiceProvider();



PaymentManager.Pay(new PaymentRequest { Titulaire = "John Doe", Amount = "100" });