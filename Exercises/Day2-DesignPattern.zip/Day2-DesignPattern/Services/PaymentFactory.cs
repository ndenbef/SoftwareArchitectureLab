using Day2DesignPattern.Models;
using Day2DesignPattern.Enums;

namespace Day2DesignPattern.Services
{
    public class PaymentFactory
    {
        private readonly IEnumerable<IPaymentService> _paymentServices;

        public PaymentFactory(IEnumerable<IPaymentService> paymentServices)
        {
            _paymentServices = paymentServices;
        }

        public string PaymentMethod(PaymentType paymenttype)
        {
            var paymentService = _paymentServices.FirstOrDefault(p => p.type == paymenttype);
            if (paymentService == null)
            {
                throw new Exception($"Payment service for {paymenttype} not found.");
            }
            
            paymentService.Pay(new PaymentRequest { Titulaire = "John Doe", Amount = "100" });
        }
    }
}