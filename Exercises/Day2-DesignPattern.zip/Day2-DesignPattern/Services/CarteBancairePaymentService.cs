using Day2DesignPattern.Models;

namespace Day2DesignPattern.Services
{
    public class CarteBancairePaymentService
    {
        private IPaymentService _ipaymentService;

        public CarteBancairePaymentService(IPaymentService ipaymentservice)
        {
            _ipaymentService = ipaymentservice;
        }

        public string Pay(PaymentRequest paymentRequest)
        {
            return $"Payment by card of {paymentRequest.Amount} sucessful";
        }
    }
}