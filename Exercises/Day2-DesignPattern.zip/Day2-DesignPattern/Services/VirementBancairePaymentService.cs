using Day2DesignPattern.Models;

namespace Day2DesignPattern.Services
{
    public class VirementBancairePaymentService
    {
        private IPaymentService _ipaymentService;

        public VirementBancairePaymentService(IPaymentService ipaymentservice)
        {
            _ipaymentService = ipaymentservice;
        }

        public string Pay(PaymentRequest paymentRequest)
        {
            return $"Bank transfer of {paymentRequest.Amount} by {paymentRequest.Titulaire} sucessful";
        }
    }
}