using Day2DesignPattern.Models;

namespace Day2DesignPattern.Services
{
    public class PaymentManager
    {
        private readonly IPaymentService _ipaymentService;

        public PaymentManager(IPaymentService ipaymentservice)
        {
            _ipaymentService = ipaymentservice;
        }

        public string Pay(PaymentRequest paymentRequest)
        {
            string result = _ipaymentService.Pay(paymentRequest);
        }
    }
}