using Day2DesignPattern.Models;
using Day2DesignPattern.Enums;

namespace Day2DesignPattern.Services
{
    public class MobileMoneyPaymentService
    {
        private IPaymentService _ipaymentService;

        public MobileMoneyPaymentService(IPaymentService ipaymentservice)
        {
            _ipaymentService = ipaymentservice;
        }

        public string Pay(PaymentRequest paymentRequest)
        {
            return $"Mobile Payment of {paymentRequest.Amount} by {paymentRequest.Titulaire} sucessful";
        }
    }
}